package com.example.formlogin;

public class Comentarios {

    String nome;
    String chat;

    public Comentarios() {
    }

    public String getNome() {return nome;}

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getChat() {
        return chat;
    }

    public void setChat(String chat) {
        this.chat = chat;
    }
}
