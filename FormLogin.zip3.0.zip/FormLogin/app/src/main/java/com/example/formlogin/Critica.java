package com.example.formlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Critica extends AppCompatActivity {


    private DatabaseReference referencia = FirebaseDatabase.getInstance().getReference();
    private EditText nome;
    private EditText chat;
    private Button comentar;
    private Button bt_visualizar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_critica);
        getSupportActionBar().hide();

        nome = findViewById(R.id.edt_nick);
        chat = findViewById(R.id.edt_coment);
        comentar = findViewById(R.id.bt_addcoment);
        bt_visualizar = findViewById(R.id.bt_visualizar);

        comentar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Comentarios c = new Comentarios();

                DatabaseReference comentario = referencia.child("comentarios");
                c.setNome(String.valueOf(nome.getText()));
                c.setChat(String.valueOf(chat.getText()));
                comentario.push().setValue(c);

                if (TextUtils.isEmpty(nome.getText().toString())){
                    nome.setError("O Campo Nick está vazio!");
                    return;
                }

                if (TextUtils.isEmpty(chat.getText().toString())){
                    chat.setError("O Campo de comentários está vazio!");
                    return;
                }

                Toast.makeText(getApplicationContext(), "O comentário de " + nome.getText() + " foi adicionado com sucesso!", Toast.LENGTH_LONG).show();

            }
        });

        bt_visualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Critica.this, VisualizarChats.class);
                startActivity(intent);


            }
        });


    }
}