package com.example.formlogin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class VisualizarChats extends AppCompatActivity {

    private DatabaseReference referencia = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference meusNomes = referencia.child("comentarios");


    private ListView listaChats;
    private ArrayList<String> nomes;

    Query nicksUsuariosQuery = meusNomes.orderByChild("nome");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar_chats);
        getSupportActionBar().hide();

        nomes = new ArrayList<>();

        nicksUsuariosQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for(DataSnapshot dados: snapshot.getChildren()){
                    Comentarios c = snapshot.getValue(Comentarios.class);
                    Comentarios com = dados.getValue(Comentarios.class);
                    nomes.add(com.getNome());

                }
                listaChats = findViewById(R.id.listChats);
                ArrayAdapter<String> adaptador = new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_list_item_1, android.R.id.text1,nomes);
                listaChats.setAdapter(adaptador);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(getApplicationContext(), "Erro ao listar nomes!" + error, Toast.LENGTH_LONG).show();

            }
        });


    }
}